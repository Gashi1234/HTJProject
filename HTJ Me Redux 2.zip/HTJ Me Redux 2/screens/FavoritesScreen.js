import { useSelector } from 'react-redux';
import { STORIES_OBJECT } from '../data/htj-stories';
import ArticleContainer from '../components/articleContainer';
import { FlatList, View, StyleSheet, Text } from 'react-native';

export default function FavoritesScreen() {
  const favoriteIds = useSelector((state) => state.favorites.ids);

  const favoriteArticles = STORIES_OBJECT.filter(
    (story) => favoriteIds.includes(story.id)
  );

  if (favoriteArticles.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>Nuk ka histori të pëlqyera/favorite!</Text>
      </View>
    );
  }

  return (
    <FlatList
      data={favoriteArticles}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <ArticleContainer itemObjProp={{ item }} /> 
      )}
    />
  );
}

const styles = StyleSheet.create({
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
  },
});
