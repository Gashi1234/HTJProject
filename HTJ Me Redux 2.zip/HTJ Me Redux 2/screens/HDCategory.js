import { Pressable, Image, View, StyleSheet, Text, FlatList } from "react-native";
import { STORIES_OBJECT } from "../data/htj-stories";
import ArticleContainer from "../components/articleContainer";

export default function HDCategory() {

    function renderHDCategory(itemObj) {
        
        // console.log(itemObj);
        // console.log(itemObj.item.category);

        if (itemObj.item.category.includes("c1")) {
            return (
                <ArticleContainer itemObjProp={itemObj} />
            );
            
            // return (
            //     <Pressable style={({ pressed }) => pressed ? styles.pressedItem : styles.card}>
            //         <View style={styles.container}>
            //             <Image source={{ uri: itemObj.item.imageUrl }} style={styles.image} />
            //             <Text style={styles.title}>{itemObj.item.title}</Text>
            //             <Text style={styles.date}>{itemObj.item.date}</Text>
            //             <Text style={styles.shortContent}>{itemObj.item.shortContent}</Text>
            //         </View>
            //     </Pressable>
            // );
            
        }
    }

    function getKey(item) {
        // {console.log(item)}
        return item.id;
    }

    return (
        <View style={styles.mainView}>
            <FlatList
                data={STORIES_OBJECT}
                renderItem={renderHDCategory}
                keyExtractor={getKey}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    mainView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
    },
});