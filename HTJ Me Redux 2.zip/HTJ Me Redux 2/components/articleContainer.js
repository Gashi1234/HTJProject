import { Pressable, View, Image, Text, StyleSheet } from "react-native";
import { useNavigation } from "@react-navigation/native";

export default function ArticleContainer({ itemObjProp }) {

    
    const navigation = useNavigation();

    function navigating() {
        navigation.navigate("Article", { itemObjPassed: itemObjProp });
    }



    return (
        <Pressable
            onPress={navigating}
            style={({ pressed }) => pressed ? [styles.card, styles.pressedItem] : styles.card}
        >
            <View style={styles.container}>
                <View style={styles.imageContainer}>
                    <Image source={{ uri: itemObjProp.item.imageUrl }} style={styles.image} />
                    <View style={styles.imageOverlay} />
                </View>
                <Text style={styles.title}>{itemObjProp.item.title}</Text>

                <View style={styles.metaContainer}>
                    <View style={[styles.badge, styles.dateBadge]}>
                        <Text style={styles.badgeText}>{itemObjProp.item.date}</Text>
                    </View>
                    <View style={[styles.badge, styles.categoryBadge]}>
                        <Text style={styles.badgeText}>{itemObjProp.item.category}</Text>
                    </View>
                </View>

                <Text style={styles.shortContent}>{itemObjProp.item.shortContent}</Text>
            </View>
        </Pressable>
    );
}

const styles = StyleSheet.create({
    card: {
        backgroundColor: '#ffffff',
        borderRadius: 16,
        overflow: 'hidden',
        marginVertical: 12,
        marginHorizontal: 16,
        elevation: 8,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.1,
        shadowRadius: 12,
        padding: 16,
    },
    pressedItem: {
        opacity: 0.8,
        transform: [{ scale: 0.98 }],
    },
    container: {
        alignItems: 'flex-start',
    },
    imageContainer: {
        width: '100%',
        height: 220,
        borderRadius: 12,
        overflow: 'hidden',
        marginBottom: 16,
        position: 'relative',
    },
    image: {
        width: '100%',
        height: '100%',
        resizeMode: 'cover',
    },
    imageOverlay: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.3)', // Darker overlay to make text more readable
        borderRadius: 12,
    },
    title: {
        fontSize: 24,
        fontWeight: '700',
        color: '#1a237e', // Same indigo color as in ArticleScreen
        marginBottom: 10,
        textAlign: 'center',
        alignSelf: 'center',
        width: '100%',
    },
    metaContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        gap: 12,
        marginBottom: 12,
        alignSelf: 'center',
    },
    badge: {
        paddingHorizontal: 14,
        paddingVertical: 6,
        borderRadius: 25,
    },
    dateBadge: {
        backgroundColor: '#e3f2fd', // Light blue for date
    },
    categoryBadge: {
        backgroundColor: '#c8e6c9', // Light green for category
    },
    badgeText: {
        fontSize: 14,
        color: '#333',
        fontWeight: '600',
    },
    shortContent: {
        fontSize: 16,
        color: '#444',
        lineHeight: 24,
        textAlign: 'center',
    },
});
