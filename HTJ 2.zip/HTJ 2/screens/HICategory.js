import { ScrollView, View, StyleSheet, Text } from "react-native";

export default function HICategory()
{
    return(
        <ScrollView>
            <View style={styles.mainView}>
                <Text>HISTORI INSPIRUESE</Text>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    mainView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
    },
});