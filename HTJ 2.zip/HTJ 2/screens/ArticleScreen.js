import { Image, Text, StyleSheet, View, ScrollView } from "react-native";

export default function ArticleScreen({ route }) {
    const itemObjReceived = route.params.itemObjPassed;
    const currentYear = new Date().getFullYear();

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <Image source={{ uri: itemObjReceived.item.imageUrl }} style={styles.image} />
            <Text style={styles.title}>{itemObjReceived.item.title}</Text>

            <View style={styles.metaRow}>
                <Text style={styles.categoryTag}>
                    {itemObjReceived.item.category.join(", ").toUpperCase()}
                </Text>
                <Text style={styles.date}>
                    {itemObjReceived.item.date}
                </Text>
            </View>

            <View style={styles.footerNoteContainer}>
                <Text style={styles.footerNote}>~ Written by HTJ • 5 min read</Text>
            </View>

            <View style={styles.contentCard}>
                <Text style={styles.content}>{itemObjReceived.item.fullContent}</Text>
            </View>

            <View style={styles.footer}>
                <Text style={styles.footerText}>© {currentYear} Histori Të Jetës</Text>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        padding: 20,
        backgroundColor: "#f9f9f9",
    },
    image: {
        width: "100%",
        height: 250,
        borderRadius: 12,
        marginBottom: 16,
    },
    title: {
        fontSize: 26,
        fontWeight: "bold",
        color: "#1a237e",
        marginBottom: 10,
        textAlign: "center",
    },
    metaRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 16,
    },
    categoryTag: {
        backgroundColor: "#e3f2fd",
        color: "#1565c0",
        fontSize: 13,
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 20,
        fontWeight: "500",
    },
    date: {
        fontSize: 13,
        color: "#1e88e5",
        fontWeight: "500",
    },
    footerNoteContainer: {
        backgroundColor: "#f1f8e9", // Light green background
        borderRadius: 12,
        paddingVertical: 10,
        paddingHorizontal: 16,
        marginTop: 12,
        alignSelf: "flex-start",
    },
    footerNote: {
        fontSize: 14,
        color: "#388e3c", // Bold green for the text
        fontWeight: "600", // Bold for emphasis
        textAlign: "center",
        fontStyle: "italic",
    },
    contentCard: {
        backgroundColor: "#fff",
        padding: 16,
        marginTop: 12,
        width: "100%",
        borderTopWidth: 1,  // Add a top border
        borderTopColor: "#e0e0e0",  // Light gray border color
    },
    content: {
        fontSize: 17,
        lineHeight: 26,
        color: "#444",
        textAlign: "justify",
    },
    footer: {
        paddingVertical: 16,
        backgroundColor: "#fff",
        alignItems: "center",
        borderTopWidth: 1,
        borderTopColor: "#e0e0e0",
    },
    footerText: {
        fontSize: 14,
        color: "#888",
        fontWeight: "500",
    },
});
