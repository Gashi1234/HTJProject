import { ScrollView, View, Text, StyleSheet, FlatList, Image, Pressable } from "react-native";
import { STORIES, STORIES_ARRAY, STORIES_OBJECT } from "../data/htj-stories";
import ArticleContainer from "../components/articleContainer";

export default function HomeScreen() {

    function renderStory(item) {
        return (
            <ArticleContainer itemObjProp={item} />
        );
    }

    return (

        <View style={styles.mainView}>
            <FlatList data={STORIES_OBJECT} renderItem={renderStory} keyExtractor={(item) => item.id} />
        </View>

    );
}

const styles = StyleSheet.create({
    mainView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",

    },
});

