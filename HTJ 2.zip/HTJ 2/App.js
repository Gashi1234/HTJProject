import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator } from '@react-navigation/drawer';

import HomeScreen from './screens/HomeScreen';
import HDCategory from './screens/HDCategory';
import HFCategory from './screens/HFCategory';
import HICategory from './screens/HICategory';
import ArticleScreen from './screens/ArticleScreen';



const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();


export default function App() {

  function DrawerNavigation() {
    return (
      <Drawer.Navigator
        screenOptions={{

        }}>
        <Drawer.Screen name="Home" component={HomeScreen} />
        <Drawer.Screen name="HisDashurie" component={HDCategory} />
        <Drawer.Screen name="HisFamiljare" component={HFCategory} />
        <Drawer.Screen name="HisInspiruese" component={HICategory} />
      </Drawer.Navigator>
    );
  }

  return (
    <>
      <StatusBar style="auto" />
      <NavigationContainer>
        <Stack.Navigator>

          <Stack.Screen name="Drawer" component={DrawerNavigation} options={{
            headerShown: false,
          }} />
          <Stack.Screen name="Article" component={ArticleScreen} />

        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
