class Stories {
    constructor(id, categoryIds, imageUrl, title, date, content) {
      this.id = id;
      this.categoryIds = categoryIds;
      this.imageUrl = imageUrl;
      this.title = title;
      this.date = date;
      this.content = content;
    }
  }
  
  export default Stories;
  