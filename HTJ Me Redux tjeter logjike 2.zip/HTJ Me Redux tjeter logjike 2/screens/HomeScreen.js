import React, { useState, useRef, useEffect } from "react";
import {
  View,
  StyleSheet,
  FlatList,
  Dimensions,
  Text,
  Animated,
  SafeAreaView,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { STORIES_OBJECT } from "../data/htj-stories";
import ArticleContainer from "../components/articleContainer";
import SliderContainer from "../components/sliderContainer";
import YouTubeContainer from "../components/youtubeContainer";
import StoriesOrVideos from "../components/StoriesOrVideos";
import SocialMediaLinks from "../components/SocialMediaInfo";

const { width } = Dimensions.get("window");

export default function HomeScreen() {
  const [selectedTab, setSelectedTab] = useState(1);
  const [contentComponent, setContentComponent] = useState(null);

  const slideAnim = useRef(new Animated.Value(0)).current;
  const toggleAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    setContentComponent(renderShkrimet());
  }, []);

  useEffect(() => {
    Animated.timing(toggleAnim, {
      toValue: selectedTab === 1 ? 0 : 1,
      duration: 250,
      useNativeDriver: false,
    }).start();
  }, [selectedTab]);

  function renderStory(item) {
    return <ArticleContainer itemObjProp={item} />;
  }

  function renderSliderImage({ item }) {
    return <SliderContainer item={item} />;
  }

  function renderHeader() {
    return (
      <>
        <LinearGradient
          colors={["#e8eaf6", "#c5cae9"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 0.5, y: 1 }}
          style={styles.sliderWrapper}
        >
          <View style={styles.sliderTitleContainer}>
            <Text style={styles.sliderTitle}>MË TË LEXUARAT</Text>
            <View style={styles.underline} />
          </View>

          <FlatList
            data={STORIES_OBJECT}
            renderItem={renderSliderImage}
            keyExtractor={(item) => item.id.toString()}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            snapToAlignment="center"
            decelerationRate="fast"
            snapToInterval={320}
            contentContainerStyle={{ paddingHorizontal: 10 }}
          />
        </LinearGradient>
        <SocialMediaLinks />
      </>
    );
  }

  function renderShkrimet() {
    return (
      <FlatList
        ListHeaderComponent={renderHeader}
        data={STORIES_OBJECT}
        renderItem={renderStory}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.mainView}
        showsVerticalScrollIndicator={false}
      />
    );
  }

  function renderIntervistat() {
    return <YouTubeContainer />;
  }

  function slideToTab(tabNumber) {
    const direction = tabNumber > selectedTab ? -1 : 1;

    Animated.timing(slideAnim, {
      toValue: direction * width,
      duration: 200,
      useNativeDriver: true,
    }).start(() => {
      setSelectedTab(tabNumber);
      setContentComponent(
        tabNumber === 1 ? renderShkrimet() : renderIntervistat()
      );
      slideAnim.setValue(direction * -width);
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 250,
        useNativeDriver: true,
      }).start();
    });
  }

  function showShkrimet() {
    if (selectedTab !== 1) {
      slideToTab(1);
    }
  }

  function showIntervistat() {
    if (selectedTab !== 2) {
      slideToTab(2);
    }
  }

  const translateX = toggleAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["0%", "100%"],
  });

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.toggleGroup}>
        <Animated.View
          style={[
            styles.toggleBackground,
            { transform: [{ translateX }] },
          ]}
        />
        <StoriesOrVideos
          onPressProp={showShkrimet}
          isActive={selectedTab === 1}
          iconChangeProp="reader"
        >
          Histori
        </StoriesOrVideos>
        <StoriesOrVideos
          onPressProp={showIntervistat}
          isActive={selectedTab === 2}
          iconChangeProp="logo-youtube"
        >
          Intervista
        </StoriesOrVideos>
      </View>

      <Animated.View style={{ flex: 1, transform: [{ translateX: slideAnim }] }}>
        {contentComponent}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#e8eaf6",
  },
  mainView: {
    backgroundColor: "#e8eaf6",
    alignItems: "center",
    paddingBottom: 40,
  },
  toggleGroup: {
    flexDirection: "row",
    alignSelf: "center",
    backgroundColor: "#d1d5db",
    borderRadius: 30,
    marginTop: 16,
    marginBottom: 10,
    overflow: "hidden",
    position: "relative",
    width: 300, // 🔧 Increased width here
    height: 48,
  },
  toggleBackground: {
    position: "absolute",
    width: "50%",
    height: "100%",
    backgroundColor: "#1a237e",
    borderRadius: 30,
    zIndex: 0,
  },
  sliderWrapper: {
    height: 310,
    width: "100%",
    borderRadius: 10,
    overflow: "hidden",
    justifyContent: "flex-start",
    alignItems: "center",
  },
  sliderTitleContainer: {
    paddingHorizontal: 20,
    paddingVertical: 6,
    borderRadius: 20,
    marginBottom: 10,
    alignItems: "center",
    backgroundColor: "transparent",
    marginTop: 20,
    zIndex: 1,
  },
  sliderTitle: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#1a237e",
    letterSpacing: 1.2,
  },
  underline: {
    width: 40,
    height: 3,
    backgroundColor: "#1a237e",
    marginTop: 6,
    borderRadius: 2,
  },
});
