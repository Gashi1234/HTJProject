import {
    View,
    Text,
    StyleSheet,
    FlatList,
    ScrollView,
  } from "react-native";
  import { LinearGradient } from "expo-linear-gradient";
  import { STORIES_OBJECT } from "../data/htj-stories";
  import ArticleContainer from "../components/articleContainer";
  import { useSelector } from "react-redux";
  
  export default function HomeScreen() {
    const arrayInRedux = useSelector((state) => state.setRedux.arrayID);
    console.log("The Array in Redux", arrayInRedux);
  
    const createNewArray = STORIES_OBJECT.filter(item =>
      arrayInRedux.includes(item.id)
    );
  
    function renderStory(item) {
      return <ArticleContainer itemObjProp={item} />;
    }
  
    let content;
  
    if (arrayInRedux.length !== 0) {
      content = (
        <FlatList
          data={createNewArray}
          renderItem={renderStory}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
        />
      );
    } else {
      content = (
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.emptyCard}>
            <Text style={styles.emoji}>💔</Text>
            <Text style={styles.emptyTitle}>Asnjë artikull i preferuar</Text>
            <Text style={styles.emptySubtitle}>
              Shto artikuj që të pëlqejnë dhe ata do shfaqen këtu.
            </Text>
          </View>
        </ScrollView>
      );
    }
  
    return (
      <LinearGradient
        colors={["#e8eaf6", "#c5cae9"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0.5, y: 1 }}
        style={styles.container}
      >
        {content}
      </LinearGradient>
    );
  }
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      paddingHorizontal: 24,
      justifyContent: "center",
      alignItems: "center",
    },
  
    listContent: {
      paddingVertical: 20,
      width: "100%",
    },
  
    scrollContent: {
      flexGrow: 1,
      justifyContent: "center",
      alignItems: "center",
    },
  
    emptyCard: {
      backgroundColor: "#ffffff",
      padding: 32,
      borderRadius: 24,
      alignItems: "center",
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 10 },
      shadowOpacity: 0.1,
      shadowRadius: 20,
      elevation: 10,
      width: "100%",
      maxWidth: 350,
    },
  
    emoji: {
      fontSize: 40,
      marginBottom: 16,
    },
  
    emptyTitle: {
      fontSize: 20,
      fontWeight: "700",
      color: "#1a237e",
      marginBottom: 8,
      textAlign: "center",
    },
  
    emptySubtitle: {
      fontSize: 16,
      color: "#555",
      textAlign: "center",
      lineHeight: 22,
    },
  });
  