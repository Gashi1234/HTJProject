import React, { useRef, useEffect } from "react";
import { Pressable, StyleSheet, View, Text, Animated } from "react-native";
import { Ionicons } from "@expo/vector-icons";

export default function StoriesOrVideos({
  children,
  onPressProp,
  isActive,
  iconChangeProp,
}) {
  const bounceAnim = useRef(new Animated.Value(1)).current;

  const handlePress = () => {
    Animated.sequence([
      Animated.timing(bounceAnim, {
        toValue: 0.9,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.spring(bounceAnim, {
        toValue: 1,
        friction: 3,
        tension: 80,
        useNativeDriver: true,
      }),
    ]).start();

    onPressProp(); // trigger parent onPress
  };

  return (
    <Pressable
      onPress={handlePress}
      style={({ pressed }) => [
        styles.wrapper,
        pressed && { transform: [{ scale: 0.97 }] },
      ]}
    >
      <Animated.View style={[styles.tab, { transform: [{ scale: bounceAnim }] }]}>
        <View style={styles.row}>
          <Ionicons
            name={iconChangeProp}
            size={18}
            color={isActive ? "#ffffff" : "#1a237e"}
            style={styles.icon}
          />
          <Text
            style={[
              styles.tabText,
              { color: isActive ? "#ffffff" : "#1a237e" },
            ]}
          >
            {children}
          </Text>
        </View>
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    zIndex: 1,
  },
  tab: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  icon: {
    marginRight: 4,
  },
  tabText: {
    fontSize: 14,
    fontWeight: "600",
    letterSpacing: 1.1,
  },
});
