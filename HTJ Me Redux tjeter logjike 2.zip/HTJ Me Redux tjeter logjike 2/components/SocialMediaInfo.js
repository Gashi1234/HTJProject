import React from "react";
import {
  View,
  StyleSheet,
  Text,
  Pressable,
  Linking,
  Platform,
} from "react-native";
import { Ionicons, FontAwesome5, MaterialCommunityIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

export default function SocialMediaLinks() {
  const openLink = async (appUrl, fallbackUrl) => {
    const supported = await Linking.canOpenURL(appUrl);
    if (supported) {
      await Linking.openURL(appUrl);
    } else {
      await Linking.openURL(fallbackUrl);
    }
  };

  return (
    <LinearGradient
      colors={["#f5f7fa", "#e8eaf6"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.wrapper}
    >
      <View style={styles.container}>
        {/* Facebook */}
        <Pressable
          onPress={() =>
            openLink(
              "fb://page/447919411994225",
              "https://www.facebook.com/historitejetes"
            )
          }
          style={({ pressed }) => [
            styles.iconButton,
            pressed && styles.pressed,
          ]}
        >
          <MaterialCommunityIcons name="facebook" size={28} color="#4267B2" />
          <Text style={styles.label}>Facebook</Text>
        </Pressable>

        {/* YouTube */}
        <Pressable
          onPress={() =>
            openLink(
              "vnd.youtube://channel/UCtBa0QlN-YuHajbqDO07oiw",
              "https://www.youtube.com/@historitejetes"
            )
          }
          style={({ pressed }) => [
            styles.iconButton,
            pressed && styles.pressed,
          ]}
        >
          <Ionicons name="logo-youtube" size={28} color="#FF0000" />
          <Text style={styles.label}>YouTube</Text>
        </Pressable>

        {/* TikTok */}
        <Pressable
          onPress={() =>
            openLink(
              "snssdk1128://user/profile/@historitejetes",
              "https://tiktok.com/@historitejetes"
            )
          }
          style={({ pressed }) => [
            styles.iconButton,
            pressed && styles.pressed,
          ]}
        >
          <FontAwesome5 name="tiktok" size={24} color="#000000" />
          <Text style={styles.label}>TikTok</Text>
        </Pressable>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    marginTop: 10,
    padding: 15,
    borderRadius: 20,
    marginHorizontal: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 6,
  },
  container: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  iconButton: {
    alignItems: "center",
    padding: 10,
    borderRadius: 14,
    backgroundColor: "#ffffff",
    width: 90,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  label: {
    marginTop: 6,
    fontSize: 13,
    color: "#1a237e",
    fontWeight: "600",
    textAlign: "center",
  },
  pressed: {
    transform: [{ scale: 0.96 }],
    opacity: 0.8,
  },
});
