import { ScrollView, View, Text, StyleSheet, FlatList, Image, Pressable } from "react-native";
import { STORIES_OBJECT } from "../data/htj-stories";
import ArticleContainer from "../components/articleContainer";
import { useSelector } from "react-redux";

export default function HomeScreen() {


    const arrayInRedux = useSelector((state) => state.setRedux.arrayID);
    console.log("The Array in Redux", arrayInRedux);

    const createNewArray = STORIES_OBJECT.filter(item => arrayInRedux.includes(item.id));



    function renderStory(item) {
        return (

            <ArticleContainer itemObjProp={item} />
        );
    }

    if (arrayInRedux.length !== 0) {
        return (
            <FlatList data={createNewArray} renderItem={renderStory} keyExtractor={(item) => item.id} />
        );
    }

    else {
        return (
            <View style={styles.emptyContainer}>
                <View style={styles.emptyCard}>
                    <Text style={styles.emoji}>💔</Text>
                    <Text style={styles.emptyTitle}>Asnjë artikull i preferuar</Text>
                    <Text style={styles.emptySubtitle}>
                        Shto artikuj që të pëlqejnë dhe ata do shfaqen këtu.
                    </Text>
                </View>
            </View>


        );
    }

}

const styles = StyleSheet.create({
    emptyContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f5f7fa',
        paddingHorizontal: 24,
      },
      
      emptyCard: {
        backgroundColor: '#ffffff',
        padding: 32,
        borderRadius: 24,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.1,
        shadowRadius: 20,
        elevation: 10,
        width: '100%',
        maxWidth: 350,
      },
      
      emoji: {
        fontSize: 40,
        marginBottom: 16,
      },
      
      emptyTitle: {
        fontSize: 20,
        fontWeight: '700',
        color: '#1a237e',
        marginBottom: 8,
        textAlign: 'center',
      },
      
      emptySubtitle: {
        fontSize: 16,
        color: '#555',
        textAlign: 'center',
        lineHeight: 22,
      },
      

});

